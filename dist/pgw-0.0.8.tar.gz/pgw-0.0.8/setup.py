from setuptools import setup

setup(name='pgw',packages=['pygwin'],version='0.0.8',author='themixray',
    description='A library for creating Python applications.',
    license='MIT',install_requires=['cython','pywin32','pygame','inputs',
     'pydub','wxPython','pyautogui','moviepy','pipwin','wave','opencv-python'])

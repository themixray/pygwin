# PyGWin
A library for creating Python applications.

[Documentation](https://github.com/themixray/pygwin/wiki)
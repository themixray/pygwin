from pygwin.surface import surface
import pygwin.keyboard as keyboard
from pygwin.console import console
from pygwin.color import color
import pygwin.gamepad as _gp
import pygwin.mouse as mouse
from pygwin.rect import rect
import pygwin.image as image
import pygwin.mixer as mixer
from pygwin.tray import tray
from pygame.locals import *
import pygwin.font as font
from pygwin._win import *
from pygwin._pg import pg
import pygwin.ui as ui
gamepad = _gp.gamepad(pg)
